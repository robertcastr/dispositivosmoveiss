package com.sqlite.listadetarefas.helper;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;


import com.sqlite.listadetarefas.model.Tarefa;

import java.util.ArrayList;
import java.util.List;

public class TarefaDAO implements ITarefaDAO {
    private SQLiteDatabase escreve;
    private SQLiteDatabase le;

    public TarefaDAO(Context context) {
        DbHelper db = new DbHelper(context);
        escreve = db.getWritableDatabase();
        le = db.getReadableDatabase();
    }

    @Override
    public boolean salvar(Tarefa tarefa) {
        ContentValues values = new ContentValues();
        values.put("nome", tarefa.getNomeTarefa());
        values.put("prioridade", tarefa.getPrioridade());
        try {
            escreve.insert(DbHelper.TABELA_TAREFAS, null, values);
            Log.i("INFO", "Tarefa salva com sucesso!");

        } catch (Exception e) {
            Log.e("INFO", "Erro ao salvar tarefa " + e.getMessage());
            return false;
        }
        return true;
    }

    @Override
    public boolean atualizar(Tarefa tarefa) {
        ContentValues values = new ContentValues();
        values.put("nome", tarefa.getNomeTarefa());
        values.put("prioridade", tarefa.getPrioridade());
        try {
            String[] args = {tarefa.getId().toString()};
            escreve.update(DbHelper.TABELA_TAREFAS, values, "id=?", args);
            Log.i("INFO", "Tarefa atualizada com sucesso!");
        } catch (Exception e) {
            Log.e("INFO", "Erro ao atualizar tarefa " + e.getMessage());
            return false;
        }
        return true;
    }

    @Override
    public boolean deletar(Tarefa tarefa) {
        try {
            String[] args = {tarefa.getId().toString()};
            escreve.delete(DbHelper.TABELA_TAREFAS, "id=?", args);
            Log.i("INFO", "Tarefa removida com sucesso!");
        } catch (Exception e) {
            Log.e("INFO", "Erro ao excluir tarefa " + e.getMessage());
            return false;
        }
        return true;
    }

    @Override
    public List<Tarefa> listar() {
        List<Tarefa> tarefas = new ArrayList<>();
        String sql = "SELECT * FROM " + DbHelper.TABELA_TAREFAS + " ;";
        Cursor cursor = le.rawQuery(sql, null);

        while (cursor.moveToNext()) {
            Tarefa tarefa = new Tarefa();

            @SuppressLint("Range") Long id = cursor.getLong(cursor.getColumnIndex("id"));
            @SuppressLint("Range") String nomeTarefa = cursor.getString(cursor.getColumnIndex("nome"));
            @SuppressLint("Range") String prioridade = cursor.getString(cursor.getColumnIndex("prioridade"));

            tarefa.setId(id);
            tarefa.setNomeTarefa(nomeTarefa);
            tarefa.setPrioridade(prioridade);
            tarefas.add(tarefa);
        }
        return tarefas;
    }
}
