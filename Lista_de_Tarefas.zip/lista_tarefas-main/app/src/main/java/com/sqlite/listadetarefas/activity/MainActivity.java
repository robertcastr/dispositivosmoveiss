package com.sqlite.listadetarefas.activity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.sqlite.listadetarefas.R;
import com.sqlite.listadetarefas.helper.DbHelper;
import com.sqlite.listadetarefas.helper.TarefaDAO;
import com.sqlite.listadetarefas.model.Tarefa;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    // Nomes: Daiane Fragoso da Silveira, Henrique 

    // criação das variáveis
    private ListView listView;
    private List<Tarefa> listaTarefas = new ArrayList<>();
    private FloatingActionButton floatingActionButton;
    private Tarefa tarefaSelecionada;
    private ArrayAdapter<String> tarefaAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // inicialização das variáveis
        Toolbar toolbar = findViewById(R.id.toolbar);
        listView = findViewById(R.id.lvopcoes);
        floatingActionButton = findViewById(R.id.fab);

        setSupportActionBar(toolbar);

        DbHelper db = new DbHelper(getApplicationContext());
        ContentValues cv = new ContentValues();
        db.getWritableDatabase().insert("tarefas", null, cv);

        setupClicks();
        setupButton();
    }

    @Override
    protected void onStart() {
        carregarListaTarefas();
        super.onStart();
    }

    //configuração do botão de adicionar tarefa
    private void setupButton() {
        floatingActionButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), AdicionarTarefaActivity.class);
            startActivity(intent);
        });
    }

    //configuração dos cliques na lista de tarefas
    private void setupClicks() {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                setOnItemClick(position);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                setOnItemLongClick(position);
                return true;
            }
        });
    }

    //método para deletar a tarefa
    private void setOnItemLongClick(int position) {
        tarefaSelecionada = listaTarefas.get(position);

        AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);

        //configuração da caixa de diálogo
        dialog.setTitle("Confirmar exclusão");
        dialog.setMessage("Deseja excluir a tarefa: " + tarefaSelecionada.getNomeTarefa() + " ?");
        dialog.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                TarefaDAO tarefaDAO = new TarefaDAO(getApplicationContext());
                if (tarefaDAO.deletar(tarefaSelecionada)) {

                    carregarListaTarefas();
                    Toast.makeText(getApplicationContext(),
                            "Sucesso ao excluir tarefa!",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(),
                            "Erro ao excluir tarefa!",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        dialog.setNegativeButton("Não", null);
        dialog.create();
        dialog.show();
    }

    //método para editar a tarefa
    private void setOnItemClick(int position) {
        Tarefa tarefaSelecionada = listaTarefas.get(position);
        Intent intent = new Intent(MainActivity.this, AdicionarTarefaActivity.class);
        intent.putExtra("tarefaSelecionada", tarefaSelecionada);
        startActivity(intent);
    }

    //método para listar as tarefas
    public void carregarListaTarefas() {

        TarefaDAO tarefaDAO = new TarefaDAO(getApplicationContext());
        listaTarefas = tarefaDAO.listar();

        ArrayList<String> tarefas = new ArrayList<>();
        for (Tarefa nomeTarefa : listaTarefas) {
            tarefas.add(nomeTarefa.getNomeTarefa());
        }

        //configuração do adapter
        tarefaAdapter = new ArrayAdapter(this, R.layout.lista_tarefa_adapter, R.id.textTarefa, tarefas);
        listView.setAdapter(tarefaAdapter);
    }

    //configuração da search app bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        MenuItem busca = menu.findItem(R.id.action_search);
        SearchView editDeBusca = (SearchView) busca.getActionView();
        editDeBusca.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Log.e("teste", query);
                //getLoaderManager().restartLoader();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newSearch) {
                tarefaAdapter.getFilter().filter(newSearch);
                return false;
            }
        });
        return true;
    }
}
