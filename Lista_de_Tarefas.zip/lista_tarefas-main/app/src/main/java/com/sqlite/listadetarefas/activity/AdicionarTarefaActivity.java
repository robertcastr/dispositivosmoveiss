package com.sqlite.listadetarefas.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.sqlite.listadetarefas.R;
import com.sqlite.listadetarefas.helper.TarefaDAO;
import com.sqlite.listadetarefas.model.Tarefa;

public class AdicionarTarefaActivity extends AppCompatActivity {

    // criação das variáveis
    private TextInputEditText editTarefa;
    private Spinner spPrioridade;
    private Tarefa tarefaAtual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar_tarefa);

        // inicialização das variáveis
        editTarefa = findViewById(R.id.textTarefa);
        spPrioridade = findViewById(R.id.spinnerPrioridade);

        mostrarNaTela();
    }

    private void mostrarNaTela() {
        tarefaAtual = (Tarefa) getIntent().getSerializableExtra("tarefaSelecionada");

        if (tarefaAtual != null) {
            editTarefa.setText(tarefaAtual.getNomeTarefa());

            switch (tarefaAtual.getPrioridade()) {
                case "Baixa":
                    spPrioridade.setSelection(1, true);
                    break;
                case "Média":
                    spPrioridade.setSelection(2, true);
                    break;
                case "Alta":
                    spPrioridade.setSelection(3, true);
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_adicionar_tarefa, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.itemSalvar:
                TarefaDAO tarefaDAO = new TarefaDAO(getApplicationContext());

                if (tarefaAtual != null) {
                    editarTarefa(tarefaDAO);
                } else {
                    salvarTarefa(tarefaDAO);
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void salvarTarefa(TarefaDAO tarefaDAO) {
        String nomeTarefa = editTarefa.getText().toString();
        String prioridade = spPrioridade.getSelectedItem().toString();
        if (!nomeTarefa.isEmpty()) {
            Tarefa tarefa = new Tarefa();
            tarefa.setNomeTarefa(nomeTarefa);
            tarefa.setPrioridade(prioridade);

            if (tarefaDAO.salvar(tarefa)) {
                finish();
                Toast.makeText(this, "Sucesso ao salvar tarefa!", Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(this, "Erro ao salvar tarefa!", Toast.LENGTH_SHORT).show();
        }
    }

    private void editarTarefa(TarefaDAO tarefaDAO) {
        String nomeTarefa = editTarefa.getText().toString();
        String prioridade = spPrioridade.getSelectedItem().toString();
        if (!nomeTarefa.isEmpty()) {
            Tarefa tarefa = new Tarefa();
            tarefa.setNomeTarefa(nomeTarefa);
            tarefa.setPrioridade(prioridade);
            tarefa.setId(tarefaAtual.getId());

            if (tarefaDAO.atualizar(tarefa)) {
                finish();
                Toast.makeText(this, "Sucesso ao atualizar tarefa!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Erro ao atualizar tarefa!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}