package com.example.newbanco;

public class Produto {
    public int id;
    public String nome,categoria,raridade,efeito,ataque,resistencia,cor;

    public Produto() {
    }

    public Produto(String nome,String categoria,String raridade,String efeito,String ataque,
                   String resistencia,String cor) {
        this.id = id;
        this.nome=nome;
        this.categoria=categoria;
        this.raridade=raridade;
        this.efeito=efeito;
        this.ataque=ataque;
        this.resistencia=resistencia;
        this.cor=cor;
    }

    @Override
    public String toString() {
        return nome + " | " + categoria +" | "+ataque+" | "+resistencia+" | "+cor;
    }

    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaridade() {
        return raridade;
    }

    public void setRaridade(String raridade) {
        this.raridade = raridade;
    }

    public String getEfeito() {
        return efeito;
    }

    public void setEfeito(String efeito) {
        this.efeito = efeito;
    }

    public String getAtaque() {
        return ataque;
    }

    public void setAtaque(String ataque) {
        this.ataque = ataque;
    }

    public String getResistencia() {
        return resistencia;
    }

    public void setResistencia(String resistencia) {
        this.resistencia = resistencia;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
}
