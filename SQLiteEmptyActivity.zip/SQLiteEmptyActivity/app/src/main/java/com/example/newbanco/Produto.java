package com.example.newbanco;

public class Produto {
    public int id;
    public String nome,categoria,raridade,efeito,ataque,resistencia,vermelho,branco,preto,azul
            ,incolor,verde;

    public Produto() {
    }

    public Produto(String nome,String categoria,String raridade,String efeito,String ataque,
                   String resistencia,String vermelho,String branco,String preto,String azul,String
                   incolor,String verde) {
        this.id = id;
        this.nome=nome;
        this.categoria=categoria;
        this.raridade=raridade;
        this.efeito=efeito;
        this.ataque=ataque;
        this.resistencia=resistencia;
        this.vermelho=vermelho;
        this.branco=branco;
        this.preto=preto;
        this.azul=azul;
        this.incolor=incolor;
        this.verde=verde;
    }

    @Override
    public String toString() {
        return nome + "|" + categoria +"|"+ataque+"|"+resistencia;
    }

    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaridade() {
        return raridade;
    }

    public void setRaridade(String raridade) {
        this.raridade = raridade;
    }

    public String getEfeito() {
        return efeito;
    }

    public void setEfeito(String efeito) {
        this.efeito = efeito;
    }

    public String getAtaque() {
        return ataque;
    }

    public void setAtaque(String ataque) {
        this.ataque = ataque;
    }

    public String getResistencia() {
        return resistencia;
    }

    public void setResistencia(String resistencia) {
        this.resistencia = resistencia;
    }

    public String getVermelho() {
        return vermelho;
    }

    public void setVermelho(String vermelho) {
        this.vermelho = vermelho;
    }

    public String getBranco() {
        return branco;
    }

    public void setBranco(String branco) {
        this.branco = branco;
    }

    public String getPreto() {
        return preto;
    }

    public void setPreto(String preto) {
        this.preto = preto;
    }

    public String getAzul() {
        return azul;
    }

    public void setAzul(String azul) {
        this.azul = azul;
    }

    public String getIncolor() {
        return incolor;
    }

    public void setIncolor(String incolor) {
        this.incolor = incolor;
    }

    public String getVerde() {
        return verde;
    }

    public void setVerde(String verde) {
        this.verde = verde;
    }
}
