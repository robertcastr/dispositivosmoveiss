package com.example.newbanco;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class FormularioActivity extends AppCompatActivity {

    private EditText etNome;
    private EditText etEfeito;
    private RadioButton raridademitica;
    private RadioButton raridaderara;
    private RadioButton raridadeincomum;
    private RadioButton raridadecomum;
    private CheckBox vermelho;
    private CheckBox branco;
    private CheckBox verde;
    private CheckBox preto;
    private CheckBox azul;
    private CheckBox incolor;
    private Spinner spataque;
    private Spinner spresistencia;
    // private EditText etID;
    private TextView tvID;
    private String raridade;
    private String cor;
    private Spinner spCategorias;
    private Button btSalvar;
    private String acao;
    private Produto produto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);
        // etID = findViewById(R.id.editID);
        etNome = findViewById(R.id.editNome);
        etEfeito = findViewById(R.id.editEfeito);
        raridademitica = findViewById(R.id.Mitica);
        raridaderara = findViewById(R.id.Rara);
        raridadeincomum = findViewById(R.id.Incomum);
        raridadecomum = findViewById(R.id.comum);
        vermelho = findViewById(R.id.checkvermelho);
        branco = findViewById(R.id.checkBranco);
        verde = findViewById(R.id.checkverde);
        preto = findViewById(R.id.checkPreto);
        azul = findViewById(R.id.checkAzul);
        incolor = findViewById(R.id.checkIncolor);
        spataque = findViewById(R.id.spinner_ataque);
        spresistencia = findViewById(R.id.spinnerres);
        spCategorias = findViewById(R.id.spinnerCategoria);
        btSalvar = findViewById(R.id.buttonSalvar);
        acao = getIntent().getStringExtra("acao");

        if (acao.equals("editar")) {
            carregarFormulario();
        }
        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvar();
            }
        });
    }

    public void salvar() {
        String nome = etNome.getText().toString();
        String efeito = etEfeito.getText().toString();
        if (nome.isEmpty() || spCategorias.getSelectedItemPosition() == 0) {
            Toast.makeText(this, "Você deve preencher ambos os campos!!", Toast.LENGTH_LONG).show();
        } else {
            if (acao.equals("inserir")) {
                produto = new Produto();
            }
            produto.setNome(nome);
            produto.setEfeito(efeito);
            produto.setCategoria(spCategorias.getSelectedItem().toString());
            if (acao.equals("inserir")) {
                ProdutoDAO.inserir(this, produto);
                etNome.setText("");
                spCategorias.setSelection(0, true);
            } else {
                ProdutoDAO.editar(this, produto);
                finish();
            }
        }
        if (nome.isEmpty() || spataque.getSelectedItemPosition() == 0) {
            Toast.makeText(this, "Você deve prrencer o campo chamado ataque!!", Toast.LENGTH_LONG).show();
        } else {
            if (acao.equals("inserir")) {
                produto = new Produto();
            }
            produto.setNome(nome);
            produto.setEfeito(efeito);
            produto.setAtaque(spataque.getSelectedItem().toString());
            if (acao.equals("inserir")) {
                ProdutoDAO.inserir(this, produto);
                etNome.setText("");
                spataque.setSelection(0, true);
            } else {
                ProdutoDAO.editar(this, produto);
                finish();
            }


        }
        if (nome.isEmpty() || spresistencia.getSelectedItemPosition() == 0) {
            Toast.makeText(this, "Você deve preencher o campo chamado resistência!!", Toast.LENGTH_LONG).show();
        } else {
            if (acao.equals("inserir")) {
                produto = new Produto();
            }
            produto.setNome(nome);
            produto.setEfeito(efeito);
            produto.setResistencia(spresistencia.getSelectedItem().toString());
            if (acao.equals("inserir")) {
                ProdutoDAO.inserir(this, produto);
                etNome.setText("");
                spresistencia.setSelection(0, true);
            } else {
                ProdutoDAO.editar(this, produto);
                finish();
            }
        }
        if(raridademitica.isChecked()){
            produto.setNome(nome);
            produto.setEfeito(efeito);
            raridade="mitica";
        }
        if(raridadeincomum.isChecked()){
            produto.setNome(nome);
            produto.setEfeito(efeito);
            raridade="incumum";
        }
        if(raridaderara.isChecked()){
            produto.setNome(nome);
            produto.setEfeito(efeito);
            raridade="rara";
        }
        if(raridadecomum.isChecked()){
            produto.setNome(nome);
            produto.setEfeito(efeito);
            raridade="comum";
        }

        if(vermelho.isChecked()){
            produto.setNome(nome);
            produto.setEfeito(efeito);
            cor="vermelho";
        }
        if(branco.isChecked()){
            produto.setNome(nome);
            produto.setEfeito(efeito);
            cor="branco";
        }
        if(verde.isChecked()){
            produto.setNome(nome);
            produto.setEfeito(efeito);
            cor="verde";
        }
        if(preto.isChecked()){
            produto.setNome(nome);
            produto.setEfeito(efeito);
            cor="preto";
        }
        if(azul.isChecked()){
            produto.setNome(nome);
            produto.setEfeito(efeito);
            cor="azul";
        }
        if(incolor.isChecked()){
            produto.setNome(nome);
            produto.setEfeito(efeito);
            cor="incolor";
        }
    }


    public void carregarFormulario() {
        int id = getIntent().getIntExtra("idProduto", 0);
        produto = ProdutoDAO.getProdutobyId(this, id);
        tvID.setText(String.valueOf(id));

        String[] categorias = getResources().getStringArray(R.array.strCategorias);
        String[] ataque = getResources().getStringArray(R.array.strataque);
        String[] resistencia = getResources().getStringArray(R.array.strres);
        for (int i = 0; i < categorias.length; i++) {
            if (produto.getCategoria().equals(categorias[i])) {
                spCategorias.setSelection(i);
                break;
            }
        }
        for(int i=0;i<ataque.length;i++){
            if(produto.getAtaque().equals(ataque[i])){
                spataque.setSelection(i);
                break;
            }
        }
        for(int i=0;i<resistencia.length;i++){
            if(produto.getResistencia().equals(resistencia[i])){
                spresistencia.setSelection(i);
                break;
            }
        }
        etNome.setText(produto.getNome());
        etEfeito.setText(produto.getEfeito());
        if(raridademitica.isChecked()){
            raridademitica.setText(produto.getRaridade());
        }
        if(raridaderara.isChecked()){
            raridaderara.setText(produto.getRaridade());
        }
        if(raridadeincomum.isChecked()){
            raridadeincomum.setText(produto.getRaridade());
        }
        if(raridadecomum.isChecked()){
            raridadecomum.setText(produto.getRaridade());
        }
        if(vermelho.isChecked()){
            vermelho.setText(produto.getCor());
        }
        if(branco.isChecked()){
            branco.setText(produto.getCor());
        }
        if(preto.isChecked()){
            preto.setText(produto.getCor());
        }
        if(verde.isChecked()){
            verde.setText(produto.getCor());
        }
        if(azul.isChecked()){
            azul.setText(produto.getCor());
        }
        if(incolor.isChecked()){
            azul.setText(produto.getCor());
        }

    }
}