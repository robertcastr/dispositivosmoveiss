package com.example.newbanco;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ProdutoDAO {

    public static void inserir(Context context,Produto produto){
        //Classe que armazena os dados no banco
        ContentValues values = new ContentValues();
        values.put("nome",produto.getNome());
        values.put("categoria",produto.getCategoria());

        Banco conn = new Banco(context);
        SQLiteDatabase db = conn.getWritableDatabase();

        db.insert("produtos",null,values);
    }

    public static void editar(Context context,Produto produto){
        System.out.println("Entrou no Editar DAO");
        ContentValues values = new ContentValues();
        values.put("nome",produto.getNome());
        values.put("categoria",produto.getCategoria());

        Banco conn = new Banco(context);
        SQLiteDatabase db = conn.getWritableDatabase();

        db.update("produtos",values," id = " + produto.getId(),null);

    }

    public static void excluir(Context context,int idProduto){
        Banco conn = new Banco(context);
        SQLiteDatabase db = conn.getWritableDatabase();

        db.delete("produtos"," id = " + idProduto,null);
    }

    public static List<Produto> getProduto(Context context){
        List<Produto> lista = new ArrayList<>();
        Banco conn = new Banco(context);
        SQLiteDatabase db = conn.getWritableDatabase();
        //Classe que percorre os registros do banco
        Cursor cursor = db.rawQuery("SELECT * FROM produtos ORDER BY nome",null);
        if(cursor.getCount()>0){
            cursor.moveToFirst();
            do{
                Produto prod = new Produto();
                prod.setId(cursor.getInt(0));
                prod.setNome(cursor.getString(1));
                prod.setCategoria(cursor.getString(2));
                lista.add(prod);
            }while(cursor.moveToNext());
        }
        return lista;
    }

    public static Produto getProdutobyId(Context context, int idProduto){
        Banco conn = new Banco(context);
        SQLiteDatabase db = conn.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM produtos WHERE id = "+idProduto,null);
        if(cursor.getCount()>0){
            cursor.moveToFirst();
            Produto prod = new Produto();
            prod.setId(cursor.getInt(0));
            prod.setNome(cursor.getString(1));
            prod.setCategoria(cursor.getString(2));
            return prod;
            }
        else
        {
            return null;
        }
    }
}
