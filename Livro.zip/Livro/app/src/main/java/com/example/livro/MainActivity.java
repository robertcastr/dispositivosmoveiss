package com.example.livro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private EditText etLivro;
    private EditText etAutor;
    private EditText etAno;
    private RadioButton rb1;
    private RadioButton rb2;
    private CheckBox cbCapa;
    private CheckBox cbRaro;
    private String tipo;
    private String capa;
    private String raro;
    private String mensagem;
    private String genero;
    private ListView lvgenero;
    private String[] lista = {"Fantasia", "Ficção científica", "Terror", "Outro"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etLivro =findViewById(R.id.editTextLivro);
        etAutor = findViewById(R.id.editTextAutor);
        etAno = findViewById(R.id.editTextAno);
        rb1 = findViewById(R.id.radioButton1);
        rb2 = findViewById(R.id.radioButton2);
        cbCapa = findViewById(R.id.checkBoxCapaDura);
        cbRaro = findViewById(R.id.checkBoxRaro);
        lvgenero = findViewById(R.id.ListViewGenero);
        //Criar Adaptador
        ArrayAdapter<String>  adaptador  = new ArrayAdapter<String>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                lista
        );

        //Adicionar Adaptador a ListView
        lvgenero.setAdapter(adaptador);
        //Adiciona Clique na Lista
        lvgenero.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                genero = lvgenero.getItemAtPosition(i).toString();
            }
        });
    }

    public void mostraMensagem(View view)
    {
        mensagem = etLivro.getText().toString()+" "+etAutor.getText().toString()+" "+etAno.getText().toString();
        if(rb1.isChecked())
        {
            tipo = "Nacional";
        }
        else
        {
            tipo = "Estrangeiro";
        }
        if(cbCapa.isChecked())
        {
            capa = "sim";
        }
        else
            capa = "não";
        if(cbRaro.isChecked())
        {
            raro = "sim";
        }
        else
        {
            raro = "não";
        }
        mensagem = mensagem +" tipo:"+tipo+" capa dura:"+capa+" Raro:"+raro+" "+genero;
        Toast.makeText(getApplicationContext(), mensagem, Toast.LENGTH_LONG).show();
    }
}